---
name: bep-charte-bim
description: >
  Rédige un BEP (BIM Execution Plan) complet et/ou une Charte BIM professionnelle
  conformes à la norme ISO 19650, adaptés au marché Maghreb/Algérie, en français,
  livrables en Word (.docx) ou PDF. Utilise ce skill dès que l'utilisateur mentionne
  "BEP", "BIM Execution Plan", "Charte BIM", "plan d'exécution BIM", "EIR",
  "protocole BIM", "convention BIM", "plan BIM projet", "document BIM projet",
  "niveaux LOD", "matrice des échanges", "MIDP", "TIDP", "CDE", "environnement
  de données commun", ou toute demande de document cadre BIM pour un projet ou
  une entreprise. Déclenche aussi sur "rédige mon BEP", "crée une charte BIM",
  "document ISO 19650", "template BEP", "BEP hôtel", "BEP immeuble", "BEP
  infrastructure", "charte BIM entreprise", "charte BIM projet".
---

# Skill : BEP & Charte BIM — ISO 19650

Rédige des documents BIM professionnels (BEP et/ou Charte BIM) conformes à
l'ISO 19650, adaptés au contexte Maghreb/Algérie, brandés BIM-SOLLUTIONS.

---

## 1. Identification du type de document demandé

Détermine ce que veut l'utilisateur :

| Document | Quand l'utiliser |
|---|---|
| **BEP** (BIM Execution Plan) | Pour un projet spécifique — décrit COMMENT le BIM sera mis en œuvre |
| **Charte BIM** | Pour une entreprise/organisation — décrit la VISION et la POLITIQUE BIM |
| **Les deux** | Projet complet avec cadre d'entreprise |

Si ce n'est pas clair, demande :
> "Souhaitez-vous un BEP pour un projet spécifique, une Charte BIM pour votre
> entreprise, ou les deux ?"

---

## 2. Collecte des informations

### Pour un BEP, demander :
- Nom et type du projet (hôtel, logements, infrastructure, industriel...)
- Maître d'ouvrage / Client
- Équipe projet (architecte, BET structure, BET MEP, entreprise générale...)
- Logiciels BIM utilisés (Revit, ArchiCAD, Navisworks...)
- CDE utilisé (ACC, BIM 360, autre...)
- Phases du projet (APS, APD, DCE, EXE, DOE...)
- Niveau d'information requis (LOD 100 à 500)
- Localisation du projet

### Pour une Charte BIM, demander :
- Nom de l'entreprise
- Secteur d'activité (MOA, MOE, entreprise générale, BET...)
- Objectifs BIM de l'entreprise
- Logiciels et CDE utilisés
- Nombre de collaborateurs BIM

---

## 3. Structure des documents

### 3A — Structure BEP (ISO 19650)

Lire `references/bep-template.md` pour la structure complète.

Sections principales :
1. Informations générales du projet
2. Objectifs et usages BIM
3. Rôles et responsabilités BIM
4. Plan de livraison de l'information (MIDP/TIDP)
5. Niveaux d'information requis (LOD/LOI/LOG)
6. Environnement de données commun (CDE)
7. Conventions de nommage et structure des fichiers
8. Processus de coordination et détection de clash
9. Planning de livraison des modèles
10. Matrice des échanges d'information
11. Exigences logicielles et formats d'échange
12. Contrôle qualité et validation des modèles

### 3B — Structure Charte BIM

Lire `references/charte-bim-template.md` pour la structure complète.

Sections principales :
1. Vision et ambition BIM
2. Périmètre d'application
3. Gouvernance BIM (rôles et responsabilités)
4. Standards et normes applicables
5. Outils et plateformes BIM
6. Processus et workflows BIM
7. Formation et montée en compétences
8. Indicateurs de performance BIM (KPI)
9. Plan de déploiement

---

## 4. Conventions BIM-SOLLUTIONS

Lire `references/conventions-bim-sollutions.md` pour les standards BSO_.

Paramètres partagés préfixés `BSO_` :
- `BSO_Classification_Code` — Code OmniClass/Uniclass
- `BSO_Label` — Désignation de l'élément
- `BSO_Lot_Travaux` — Lot de travaux
- `BSO_Prix_Unitaire` — Prix unitaire
- `BSO_Unite` — Unité de mesure
- `BSO_Cout_Total` — Coût total calculé

---

## 5. Rédaction du document

### Règles de rédaction
- **Langue** : Français professionnel (algérien/maghrébin)
- **Ton** : Formel, technique, précis
- **Normes citées** : ISO 19650-1, ISO 19650-2, EN 17412
- **Adaptation locale** : Mentionner le contexte réglementaire algérien si pertinent

### En-tête de chaque document
```
[Logo BIM-SOLLUTIONS]
Document : BEP / Charte BIM
Projet : [Nom]
Référence : BSO-BEP-[Année]-[NumeroProjet]
Version : 1.0
Date : [Date]
Rédigé par : BIM-SOLLUTIONS — Ouafek Mahizi, BIM Manager
```

### Pied de page
```
BIM-SOLLUTIONS | bim-solution-dz.com
Contact : modelisation@bim-solution-dz.com
© BIM-SOLLUTIONS — Tous droits réservés
```

---

## 6. Format de livraison

### Option A — Word (.docx)
- Utiliser le skill `docx` pour la génération
- Styles : Titre1, Titre2, Corps de texte, Tableau
- Couleurs BIM-SOLLUTIONS : Bleu marine `#1B2A4A` + Rouge `#C0392B`

### Option B — Réponse directe en Markdown
- Pour prévisualisation rapide
- L'utilisateur peut copier-coller

### Demander à l'utilisateur :
> "Souhaitez-vous le document en Word (.docx) téléchargeable ou en aperçu
> direct dans le chat ?"

---

## 7. Tableau des usages BIM standards

| Usage BIM | Phase | Discipline | Priorité |
|---|---|---|---|
| Modélisation architecturale | APS→EXE | Architecture | Haute |
| Modélisation structurale | APD→EXE | Structure | Haute |
| Modélisation MEP | APD→EXE | MEP | Haute |
| Coordination / Clash | APD→EXE | Toutes | Haute |
| Extraction des quantités | DCE→EXE | Toutes | Haute |
| Planning 4D | EXE | Toutes | Moyenne |
| Estimation 5D | DCE | Toutes | Moyenne |
| DOE / As-Built | Livraison | Toutes | Haute |
| Facility Management | Exploitation | Toutes | Basse→Haute |

---

## 8. Matrice LOD standard

| Phase | LOD Architecture | LOD Structure | LOD MEP |
|---|---|---|---|
| Esquisse | 100 | 100 | 100 |
| APS | 200 | 200 | 200 |
| APD | 300 | 300 | 300 |
| DCE | 350 | 350 | 350 |
| EXE | 400 | 400 | 400 |
| DOE | 500 | 500 | 500 |

---

## 9. Références à lire selon le besoin

| Besoin | Fichier à lire |
|---|---|
| Structure détaillée BEP | `references/bep-template.md` |
| Structure détaillée Charte BIM | `references/charte-bim-template.md` |
| Conventions BSO_ et nommage | `references/conventions-bim-sollutions.md` |

---

## 10. Checklist finale avant livraison

- [ ] Toutes les sections sont complètes
- [ ] Références normatives citées (ISO 19650)
- [ ] Matrice des responsabilités remplie
- [ ] Conventions de nommage définies
- [ ] Niveaux LOD spécifiés par phase et discipline
- [ ] CDE et logiciels identifiés
- [ ] En-tête et pied de page BIM-SOLLUTIONS présents
- [ ] Numéro de référence BSO- attribué
- [ ] Version et date correctes
